//
//  GameEvents.swift
//  Choose Figure
//
//  Created by Yunpeng Huo on 2018/5/23.
//  Copyright © 2018年 UTS. All rights reserved.
//

import Foundation

protocol GameEvents {
    var level: Int { get set }
    var lives: Int { get set }
    
    func RightChoice(index: Int)
    func WrongChoice()
    
    func gameOver()
    func moveToNextLevel()
}
