//
//  GameActions.swift
//  Choose Figure
//
//  Created by Yunpeng Huo on 2018/5/23.
//  Copyright © 2018年 UTS. All rights reserved.
//

import Foundation

protocol GameActions {
    var list: [String] { get }
    var rightFigureName: String? { get }
    
    func Choose(index: Int)
    init(delegate: GameEvents, deckSize: Int)
}
