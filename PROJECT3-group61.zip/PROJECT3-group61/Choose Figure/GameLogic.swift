//
//  GameLogic.swift
//  Choose Figure
//
//  Created by Yunpeng Huo on 2018/5/23.
//  Copyright © 2018年 UTS. All rights reserved.
//

import SpriteKit

let minFigure = 3
let maxFigure = 5

class GameLogic {
    var delegate: GameEvents?
    
    var list: [String]  = []
    var rightFigureName: String?

    var deck: [Int] = []
    var availableNames: [String] = []
    var Choose: Int?
    var deckSize: Int?
    var rightFigureIndex: Int?
    var figuresToChoose: [Int] = []

    required init(delegate: GameEvents, deckSize: Int) {
        self.delegate = delegate
        self.deckSize = deckSize
        self.Choose = Int.random(minNum:minFigure, maxNum:maxFigure)
        
        let level = delegate.level
        self.availableNames = figureLevel(level: level)
        self.rightFigureIndex = Int.random(minNum:0, maxNum: availableNames.count - 1)
        self.rightFigureName = availableNames[rightFigureIndex!]
        self.deck = generateDeckOfIndices()
        self.list = self.deck.map({ index in availableNames[index]
        })
    }
}

extension GameLogic {
    
    private func figureLevel(level: Int) -> [String] {
        if level > 44 {
            return figureLevel(level: 44)
        }
        
        if level == 1 {
            return ["1_1", "1_2", "1_3"]
        } else {
            var newImage: [String] = []
            if level % 2 == 0 {
                newImage += [String(level)]
            }
            return figureLevel(level: level - 1) + newImage
        }
    }
    
    private func generateDeckOfIndices() -> [Int] {
        let forbiddenValue = rightFigureIndex!
        var list = Int.randoms(numberOfRandoms: deckSize!, minNum: 0, maxNum: availableNames.count - 1, forbiddenValues: [forbiddenValue])
        let chosenIndices = Int.uniqueRandoms(numberOfRandoms: Choose!, minNum: 0, maxNum: deckSize! - 1)
        self.figuresToChoose = chosenIndices
        for index in chosenIndices {
            list[index] = rightFigureIndex!
        }
        return list
    }
}

extension GameLogic: GameActions {
    
    func Choose(index: Int) {
        let figureList = deck[index]
        if figureList == rightFigureIndex {
            if let indexInArray = figuresToChoose.index(of: index){
                self.delegate?.RightChoice(index: index)
                self.figuresToChoose.remove(at: indexInArray)
                if figuresToChoose.count == 0 {
                    self.delegate?.moveToNextLevel()
                }
            }
        } else {
            self.delegate?.WrongChoice()
            self.delegate?.lives -= 1
            if self.delegate?.lives == 0 {
                self.delegate?.gameOver()
            }
        }
    }
    
}






