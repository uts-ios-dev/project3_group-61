
import SpriteKit


class GameScene: SKScene {
    
    var level: Int = 1
    var logic: GameActions?
    
    var levelLabelNode: SKLabelNode?
    var rightFigureNode: SKSpriteNode?
    var deckNodes: [SKSpriteNode] = []
    var lifeNodes: [SKSpriteNode] = []
    var lives: Int = 3
    var theTime  = 0
    var textLabel: SKLabelNode?
    var onClick = 0
    var clickLabel: SKLabelNode?
    
    override func didMove(to view: SKView) {
        
        initializeGame()

        let TimeLabel = SKLabelNode(fontNamed: "Times")
        TimeLabel.text = "Time:"
        TimeLabel.fontSize = 30
        TimeLabel.fontColor = SKColor.black
        TimeLabel.position = CGPoint(x: 80 , y: 240)
        TimeLabel.zPosition = 1
        self.addChild(TimeLabel)
        
        
        let clickLabel = SKLabelNode(fontNamed: "Times")
        clickLabel.text = "Clicked:"
        clickLabel.fontSize = 30
        clickLabel.fontColor = SKColor.black
        clickLabel.position = CGPoint(x: -100 , y: 240)
        clickLabel.zPosition = 1
        self.addChild(clickLabel)
        
        self.levelLabelNode = childNode(withName: "level") as? SKLabelNode
        self.rightFigureNode = childNode(withName: "rightFigure") as? SKSpriteNode
        enumerateChildNodes(withName: "//*") {
            node, stop in
            if node.name == "figure" {
                self.deckNodes.append(node as! SKSpriteNode)
            }
            if node.name == "life" {
                self.lifeNodes.append(node as! SKSpriteNode)
            }
        }
        self.levelLabelNode?.text = String(level)

        self.logic = GameLogic(delegate: self, deckSize: deckNodes.count)

        drawDeck()
        drawRightFigure()
        drawLives()
    }
    
    
   func initializeGame(){
    
    textLabel = (childNode(withName: "textLabel") as? SKLabelNode?)!
    textLabel?.text = "0"
    clickLabel = (childNode(withName: "scoreLabel") as? SKLabelNode?)!
    clickLabel?.text = "0"
    Timer.scheduledTimer(timeInterval: (1), target: self, selector: #selector(addTimer), userInfo: nil, repeats: true)
    Timer.scheduledTimer(timeInterval: (1), target: self, selector: #selector(addClick), userInfo: nil, repeats: true)
    }
  
    @objc func addTimer(){
        if (theTime >= 0 ){
            theTime += 1
            textLabel?.text = String(theTime)
        }
    }
    
    @objc func addClick(){
        clickLabel?.text = String(onClick)
    }
    
}

extension GameScene {
    
    func drawDeck() {
        for (index, node) in deckNodes.enumerated() {
            let name = logic?.list[index]
            node.texture = SKTexture(imageNamed: name!)
        }
    }
    
    func drawRightFigure() {
        let name = logic?.rightFigureName
        self.rightFigureNode?.texture = SKTexture(imageNamed: name!)
    }
    
    func drawLives() {
        if lives < 3 {
            for index in lives...2 {
                let node = lifeNodes[index]
                node.alpha = 0.2
            }
        }
    }
    
}

extension GameScene: GameEvents {

    func RightChoice(index: Int) {
        _ = deckNodes[index]
        print("GOOD!!")
        onClick = onClick + 1
        print("Clicked: \(onClick)")
    }
    
    func WrongChoice() {
        let index = lives - 1
        let lifeNode = lifeNodes[index]
        if index <= 0{
            gameOver()
        }
        
        let action = SKAction.fadeAlpha(to: 0.2, duration: 0.1)
        lifeNode.run(action)
        print("Fail!!! Lives: \(lives)")
    }
    
}

extension GameScene {

    func gameOver() {
        let sceneToMoveTo = GameOverScene(size: self.size)
        sceneToMoveTo.scaleMode = self.scaleMode
        let myTransition = SKTransition.fade(withDuration: (0.5))
        self.view!.presentScene(sceneToMoveTo, transition: myTransition)
        
        
    }
    
    func moveToNextLevel() {
        
        let transition = SKTransition.crossFade(withDuration: 0)
        
        let nextLevelScene = GameScene(fileNamed:"GameScene")
        nextLevelScene!.level = level + 1
        nextLevelScene!.lives = lives
        nextLevelScene!.scaleMode = SKSceneScaleMode.aspectFill
        self.scene!.view?.presentScene(nextLevelScene!, transition: transition)
    }
}

extension GameScene {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let position = touch.location(in: self)
            let node = self.atPoint(position)
            if node.name == "figure" {
                let figure = node as? SKSpriteNode
                let index = deckNodes.index(of: figure!)
                self.logic?.Choose(index: index!)
            }
        }
    }
}













