//
//  GameOverScene.swift
//  Choose Figure
//
//  Created by Yunpeng Huo on 2018/5/23.
//  Copyright © 2018年 UTS. All rights reserved.
//

import UIKit
import SpriteKit
class GameOverScene: SKScene {
override func didMove(to view: SKView) {
    let gameOverLabel = SKLabelNode(fontNamed: "Times")
    gameOverLabel.text = "Game Over"
    gameOverLabel.fontSize = 50
    gameOverLabel.fontColor = SKColor.yellow
    gameOverLabel.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.8)
    gameOverLabel.zPosition = 1
    self.addChild(gameOverLabel)
    
    let background = SKSpriteNode(imageNamed:"background1")
    background.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
    background.zPosition = 0
    self.addChild(background)

    let restartLabel = SKLabelNode(fontNamed: "Times")
    restartLabel.text = "Restart"
    restartLabel.name = "RestartButton"
    restartLabel.fontSize = 55
    restartLabel.fontColor = SKColor.red
    restartLabel.zPosition = 1
    restartLabel.position = CGPoint(x: self.size.width / 2, y: self.size.height * 0.42)
    self.addChild(restartLabel)
    
}

override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    for touch in touches{
        let location = touch.location(in: self);
        if atPoint(location).name == "RestartButton"{
            if let scene = GameScene(fileNamed: "GameScene") {
                scene.scaleMode = .aspectFill
                view!.presentScene(scene, transition: SKTransition.doorsOpenVertical(withDuration: TimeInterval(0.5)));
            }
        }
    }
}
}

